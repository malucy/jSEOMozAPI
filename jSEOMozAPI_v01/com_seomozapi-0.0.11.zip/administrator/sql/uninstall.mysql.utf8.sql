DROP TABLE IF EXISTS `#__seomozapi_request`;
