jSEOMozAPI
==========

Joomla tool for consuming the SEOMoz API tools